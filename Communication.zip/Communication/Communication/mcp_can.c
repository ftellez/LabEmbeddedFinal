/*
 * mcp_can.c
 *
 * Created: 6/20/2018 10:26:17 AM
 *  Author: rg93876
 */ 

/** Includes *******************************/
#include "mcp_can.h"

uint8_t mcpIDExtFlg;					// Identifier type ( Extended or standard)
uint32_t mcpID;							// CAN ID
uint8_t mcpDataLen;						// Data Length
uint8_t mcpData[MAX_CHAR_IN_MESSAGE];	// Data Array
uint8_t mcpRemoteFlg;					// Remote request flag
uint8_t mcpFilterHit;					// Number of filter that matches the filter
uint8_t mcpChipSelect;				// MCP CAN Shield Chip Select
uint8_t mcpMode;					// Mode to return after perform configurations.

/*******************************************************************
*
*    FUNCTION: mcp2515_reset
*
* DESCRIPTION: Performs a software reset.
*
*  PARAMETERS: N/A
*
*     RETURNS: N/A
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
void mcp2515_reset(void)
{
	SPI_Slave_Select(mcpChipSelect);
	spiSend(MCP_RESET);
	SPI_Slave_Unselect(mcpChipSelect);
}

/*******************************************************************
*
*    FUNCTION: mcp2515_readRegister
*
* DESCRIPTION: Read data register.
*
*  PARAMETERS:	address: MCP2515 register address.
*
*     RETURNS: response: Data from MCP2515 register.
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t mcp2515_readRegister(const uint8_t address)
{
	uint8_t response = 0;
	
	SPI_Slave_Select(mcpChipSelect);
	spiSend(MCP_READ);
	spiSend(address);
	response = spiSend(DUMMY);
	SPI_Slave_Unselect(mcpChipSelect);
	
	return response;
}

/*******************************************************************
*
*    FUNCTION: mcp2515_readRegisterSuccessive
*
* DESCRIPTION: Read successive data registers
*
*  PARAMETERS:	address: MCP2515 register address.
*				values:	 Buffer to save MCP2515 returned data.
*				numRegToRead:  Number of registers to read form MCP2515.
*
*     RETURNS: N/A
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
void mcp2515_readRegisterSuccessive(const uint8_t address, uint8_t values[], const uint8_t numRegToRead) 
{
	uint8_t i = 0;
	
	SPI_Slave_Select(mcpChipSelect);
	spiSend(MCP_READ);
	spiSend(address);
	// mcp2515 has auto-increment of address-pointer
	for ( i = 0; i < numRegToRead && i < MAX_CHAR_IN_MESSAGE; i++ )
	{
		values[i] = spiSend(DUMMY);
	}
	SPI_Slave_Unselect(mcpChipSelect);
}

/*******************************************************************
*
*    FUNCTION: mcp2515_setRegister
*
* DESCRIPTION: Set value to MCP2515 data register.
*
*  PARAMETERS:	address: MCP2515 register address.
*				value:	 Value to save in register.
*
*     RETURNS: N/A
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
void mcp2515_setRegister(const uint8_t address, const uint8_t value)
{	
	SPI_Slave_Select(mcpChipSelect);
	spiSend(MCP_WRITE);
	spiSend(address);
	spiSend(value);
	SPI_Slave_Unselect(mcpChipSelect);
}

/*******************************************************************
*
*    FUNCTION: mcp2515_setRegisterSuccessive
*
* DESCRIPTION: Set value to MCP2515 successive registers.
*
*  PARAMETERS:	address: MCP2515 register address.
*				values:	 Values to save in registers.
*				numRegToWrite:  Number of registers to write to MCP2515.
*
*     RETURNS: N/A
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
void mcp2515_setRegisterSuccessive(const uint8_t address, const uint8_t values[], const uint8_t numRegToWrite)
{
	uint8_t i = 0;
	
	SPI_Slave_Select(mcpChipSelect);
	spiSend(MCP_WRITE);
	spiSend(address);
	for ( i = 0; i < numRegToWrite && i < MAX_CHAR_IN_MESSAGE; i++ )
	{
		spiSend(values[i]);
	}
	SPI_Slave_Unselect(mcpChipSelect);
}

/*******************************************************************
*
*    FUNCTION: mcp2515_modifyRegister
*
* DESCRIPTION: Sets specific bits of a register
*
*  PARAMETERS:	address: MCP2515 register address.
*				mask:	 Bit mask of register.
*				data:	 Data to save to register.
*				mcpChipSelect: MCP2515 Chip Select pin.
*
*     RETURNS: N/A
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
void mcp2515_modifyRegister(const uint8_t address, const uint8_t mask, const uint8_t data)
{
	SPI_Slave_Select(mcpChipSelect);
	spiSend(MCP_BITMOD);
	spiSend(address);
	spiSend(mask);
	spiSend(data);
	SPI_Slave_Unselect(mcpChipSelect);
}

/*******************************************************************
*
*    FUNCTION: mcp2515_readStatus
*
* DESCRIPTION: Read MCP2515 Status
*
*  PARAMETERS: mcpChipSelect: MCP2515 Chip Select pin.
*
*     RETURNS: response: data of MCP2515 status register
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t mcp2515_readStatus(void)
{
	uint8_t response = 0;
	
	SPI_Slave_Select(mcpChipSelect);
	spiSend(MCP_READ_STATUS);
	response = spiSend(DUMMY);
	SPI_Slave_Unselect(mcpChipSelect);
	
	return response;
}

/*******************************************************************
*
*    FUNCTION: mcp2515_setMode
*
* DESCRIPTION: Set control mode
*
*  PARAMETERS:  operationMode: Operation mode to set to MCP2515.
*				mcpMode: Pointer to MCP2515 operation mode.
*
*     RETURNS: mcpStatus: MCP2515 status after modifying register.
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t mcp2515_setCANCTRL_Mode(const uint8_t operationMode)
{
	uint8_t newMode = 0;
	uint8_t mcpStatus = MCP2515_FAIL;
	
	mcp2515_modifyRegister(MCP_CANCTRL, MODE_MASK, operationMode);
	newMode = mcp2515_readRegister(MCP_CANCTRL);
	newMode &= MODE_MASK;
	
	if ( newMode == operationMode )
	{
		mcpStatus = MCP2515_OK;
	}
	
	return mcpStatus;
}

/*******************************************************************
*
*    FUNCTION: mcp2515_configRate
*
* DESCRIPTION: Set baud rate
*
*  PARAMETERS:  canSpeed: CAN speed to set.
*				canClock: CAN clock to set.
*
*     RETURNS: mcpStatus: MCP2515 status after modifying register.
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t mcp2515_configRate( const uint8_t canSpeed, const uint8_t canClock)
{
	uint8_t setCfg, cfg1, cfg2, cfg3;
	setCfg = 1;
	switch (canClock)
	{
		case (MCP_8MHZ):
		switch (canSpeed)
		{
			case (CAN_5KBPS):                                               //   5KBPS
			cfg1 = MCP_8MHz_5kBPS_CFG1;
			cfg2 = MCP_8MHz_5kBPS_CFG2;
			cfg3 = MCP_8MHz_5kBPS_CFG3;
			break;

			case (CAN_10KBPS):                                              //  10KBPS
			cfg1 = MCP_8MHz_10kBPS_CFG1;
			cfg2 = MCP_8MHz_10kBPS_CFG2;
			cfg3 = MCP_8MHz_10kBPS_CFG3;
			break;

			case (CAN_20KBPS):                                              //  20KBPS
			cfg1 = MCP_8MHz_20kBPS_CFG1;
			cfg2 = MCP_8MHz_20kBPS_CFG2;
			cfg3 = MCP_8MHz_20kBPS_CFG3;
			break;

			case (CAN_31K25BPS):                                            //  31.25KBPS
			cfg1 = MCP_8MHz_31k25BPS_CFG1;
			cfg2 = MCP_8MHz_31k25BPS_CFG2;
			cfg3 = MCP_8MHz_31k25BPS_CFG3;
			break;

			case (CAN_33K3BPS):                                             //  33.33KBPS
			cfg1 = MCP_8MHz_33k3BPS_CFG1;
			cfg2 = MCP_8MHz_33k3BPS_CFG2;
			cfg3 = MCP_8MHz_33k3BPS_CFG3;
			break;

			case (CAN_40KBPS):                                              //  40Kbps
			cfg1 = MCP_8MHz_40kBPS_CFG1;
			cfg2 = MCP_8MHz_40kBPS_CFG2;
			cfg3 = MCP_8MHz_40kBPS_CFG3;
			break;

			case (CAN_50KBPS):                                              //  50Kbps
			cfg1 = MCP_8MHz_50kBPS_CFG1;
			cfg2 = MCP_8MHz_50kBPS_CFG2;
			cfg3 = MCP_8MHz_50kBPS_CFG3;
			break;

			case (CAN_80KBPS):                                              //  80Kbps
			cfg1 = MCP_8MHz_80kBPS_CFG1;
			cfg2 = MCP_8MHz_80kBPS_CFG2;
			cfg3 = MCP_8MHz_80kBPS_CFG3;
			break;

			case (CAN_100KBPS):                                             // 100Kbps
			cfg1 = MCP_8MHz_100kBPS_CFG1;
			cfg2 = MCP_8MHz_100kBPS_CFG2;
			cfg3 = MCP_8MHz_100kBPS_CFG3;
			break;

			case (CAN_125KBPS):                                             // 125Kbps
			cfg1 = MCP_8MHz_125kBPS_CFG1;
			cfg2 = MCP_8MHz_125kBPS_CFG2;
			cfg3 = MCP_8MHz_125kBPS_CFG3;
			break;

			case (CAN_200KBPS):                                             // 200Kbps
			cfg1 = MCP_8MHz_200kBPS_CFG1;
			cfg2 = MCP_8MHz_200kBPS_CFG2;
			cfg3 = MCP_8MHz_200kBPS_CFG3;
			break;

			case (CAN_250KBPS):                                             // 250Kbps
			cfg1 = MCP_8MHz_250kBPS_CFG1;
			cfg2 = MCP_8MHz_250kBPS_CFG2;
			cfg3 = MCP_8MHz_250kBPS_CFG3;
			break;

			case (CAN_500KBPS):                                             // 500Kbps
			cfg1 = MCP_8MHz_500kBPS_CFG1;
			cfg2 = MCP_8MHz_500kBPS_CFG2;
			cfg3 = MCP_8MHz_500kBPS_CFG3;
			break;
			
			case (CAN_1000KBPS):                                            //   1Mbps
			cfg1 = MCP_8MHz_1000kBPS_CFG1;
			cfg2 = MCP_8MHz_1000kBPS_CFG2;
			cfg3 = MCP_8MHz_1000kBPS_CFG3;
			break;

			default:
			setCfg = 0;
			return MCP2515_FAIL;
			break;
		}
		break;

		case (MCP_16MHZ):
		switch (canSpeed)
		{
			case (CAN_5KBPS):                                               //   5Kbps
			cfg1 = MCP_16MHz_5kBPS_CFG1;
			cfg2 = MCP_16MHz_5kBPS_CFG2;
			cfg3 = MCP_16MHz_5kBPS_CFG3;
			break;

			case (CAN_10KBPS):                                              //  10Kbps
			cfg1 = MCP_16MHz_10kBPS_CFG1;
			cfg2 = MCP_16MHz_10kBPS_CFG2;
			cfg3 = MCP_16MHz_10kBPS_CFG3;
			break;

			case (CAN_20KBPS):                                              //  20Kbps
			cfg1 = MCP_16MHz_20kBPS_CFG1;
			cfg2 = MCP_16MHz_20kBPS_CFG2;
			cfg3 = MCP_16MHz_20kBPS_CFG3;
			break;

			case (CAN_33K3BPS):                                              //  20Kbps
			cfg1 = MCP_16MHz_33k3BPS_CFG1;
			cfg2 = MCP_16MHz_33k3BPS_CFG2;
			cfg3 = MCP_16MHz_33k3BPS_CFG3;
			break;

			case (CAN_40KBPS):                                              //  40Kbps
			cfg1 = MCP_16MHz_40kBPS_CFG1;
			cfg2 = MCP_16MHz_40kBPS_CFG2;
			cfg3 = MCP_16MHz_40kBPS_CFG3;
			break;

			case (CAN_50KBPS):                                              //  50Kbps
			cfg2 = MCP_16MHz_50kBPS_CFG2;
			cfg3 = MCP_16MHz_50kBPS_CFG3;
			break;

			case (CAN_80KBPS):                                              //  80Kbps
			cfg1 = MCP_16MHz_80kBPS_CFG1;
			cfg2 = MCP_16MHz_80kBPS_CFG2;
			cfg3 = MCP_16MHz_80kBPS_CFG3;
			break;

			case (CAN_100KBPS):                                             // 100Kbps
			cfg1 = MCP_16MHz_100kBPS_CFG1;
			cfg2 = MCP_16MHz_100kBPS_CFG2;
			cfg3 = MCP_16MHz_100kBPS_CFG3;
			break;

			case (CAN_125KBPS):                                             // 125Kbps
			cfg1 = MCP_16MHz_125kBPS_CFG1;
			cfg2 = MCP_16MHz_125kBPS_CFG2;
			cfg3 = MCP_16MHz_125kBPS_CFG3;
			break;

			case (CAN_200KBPS):                                             // 200Kbps
			cfg1 = MCP_16MHz_200kBPS_CFG1;
			cfg2 = MCP_16MHz_200kBPS_CFG2;
			cfg3 = MCP_16MHz_200kBPS_CFG3;
			break;

			case (CAN_250KBPS):                                             // 250Kbps
			cfg1 = MCP_16MHz_250kBPS_CFG1;
			cfg2 = MCP_16MHz_250kBPS_CFG2;
			cfg3 = MCP_16MHz_250kBPS_CFG3;
			break;

			case (CAN_500KBPS):                                             // 500Kbps
			cfg1 = MCP_16MHz_500kBPS_CFG1;
			cfg2 = MCP_16MHz_500kBPS_CFG2;
			cfg3 = MCP_16MHz_500kBPS_CFG3;
			break;
			
			case (CAN_1000KBPS):                                            //   1Mbps
			cfg1 = MCP_16MHz_1000kBPS_CFG1;
			cfg2 = MCP_16MHz_1000kBPS_CFG2;
			cfg3 = MCP_16MHz_1000kBPS_CFG3;
			break;

			default:
			setCfg = 0;
			return MCP2515_FAIL;
			break;
		}
		break;
		
		case (MCP_20MHZ):
		switch (canSpeed)
		{
			case (CAN_40KBPS):                                              //  40Kbps
			cfg1 = MCP_20MHz_40kBPS_CFG1;
			cfg2 = MCP_20MHz_40kBPS_CFG2;
			cfg3 = MCP_20MHz_40kBPS_CFG3;
			break;

			case (CAN_50KBPS):                                              //  50Kbps
			cfg1 = MCP_20MHz_50kBPS_CFG1;
			cfg2 = MCP_20MHz_50kBPS_CFG2;
			cfg3 = MCP_20MHz_50kBPS_CFG3;
			break;

			case (CAN_80KBPS):                                              //  80Kbps
			cfg1 = MCP_20MHz_80kBPS_CFG1;
			cfg2 = MCP_20MHz_80kBPS_CFG2;
			cfg3 = MCP_20MHz_80kBPS_CFG3;
			break;

			case (CAN_100KBPS):                                             // 100Kbps
			cfg1 = MCP_20MHz_100kBPS_CFG1;
			cfg2 = MCP_20MHz_100kBPS_CFG2;
			cfg3 = MCP_20MHz_100kBPS_CFG3;
			break;

			case (CAN_125KBPS):                                             // 125Kbps
			cfg1 = MCP_20MHz_125kBPS_CFG1;
			cfg2 = MCP_20MHz_125kBPS_CFG2;
			cfg3 = MCP_20MHz_125kBPS_CFG3;
			break;

			case (CAN_200KBPS):                                             // 200Kbps
			cfg1 = MCP_20MHz_200kBPS_CFG1;
			cfg2 = MCP_20MHz_200kBPS_CFG2;
			cfg3 = MCP_20MHz_200kBPS_CFG3;
			break;

			case (CAN_250KBPS):                                             // 250Kbps
			cfg1 = MCP_20MHz_250kBPS_CFG1;
			cfg2 = MCP_20MHz_250kBPS_CFG2;
			cfg3 = MCP_20MHz_250kBPS_CFG3;
			break;

			case (CAN_500KBPS):                                             // 500Kbps
			cfg1 = MCP_20MHz_500kBPS_CFG1;
			cfg2 = MCP_20MHz_500kBPS_CFG2;
			cfg3 = MCP_20MHz_500kBPS_CFG3;
			break;
			
			case (CAN_1000KBPS):                                            //   1Mbps
			cfg1 = MCP_20MHz_1000kBPS_CFG1;
			cfg2 = MCP_20MHz_1000kBPS_CFG2;
			cfg3 = MCP_20MHz_1000kBPS_CFG3;
			break;

			default:
			setCfg = 0;
			return MCP2515_FAIL;
			break;
		}
		break;
		
		default:
		setCfg = 0;
		return MCP2515_FAIL;
		break;
	}

	if (setCfg) {
		mcp2515_setRegister(MCP_CNF1, cfg1);
		mcp2515_setRegister(MCP_CNF2, cfg2);
		mcp2515_setRegister(MCP_CNF3, cfg3);
		return MCP2515_OK;
	}
	
	return MCP2515_FAIL;
}

/*******************************************************************
*
*    FUNCTION: mcp2515_initCANBuffers
*
* DESCRIPTION: Initialize buffers, Masks and filters
*
*  PARAMETERS: N/A
*
*     RETURNS: N/A
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
void mcp2515_initCANBuffers(void)
{
	uint8_t i, a1, a2, a3;
	
	uint8_t std = 0;
	uint8_t ext = 1;
	uint32_t ulMask = 0x00, ulFilt = 0x00;


	mcp2515_write_mf(MCP_RXM0SIDH, ext, ulMask);			/*Set both masks to 0           */
	mcp2515_write_mf(MCP_RXM1SIDH, ext, ulMask);			/*Mask register ignores ext bit */
	
	/* Set all filters to 0         */
	mcp2515_write_mf(MCP_RXF0SIDH, ext, ulFilt);			/* RXB0: extended               */
	mcp2515_write_mf(MCP_RXF1SIDH, std, ulFilt);			/* RXB1: standard               */
	mcp2515_write_mf(MCP_RXF2SIDH, ext, ulFilt);			/* RXB2: extended               */
	mcp2515_write_mf(MCP_RXF3SIDH, std, ulFilt);			/* RXB3: standard               */
	mcp2515_write_mf(MCP_RXF4SIDH, ext, ulFilt);
	mcp2515_write_mf(MCP_RXF5SIDH, std, ulFilt);

	/* Clear, deactivate the three  */
	/* transmit buffers             */
	/* TXBnCTRL -> TXBnD7           */
	a1 = MCP_TXB0CTRL;
	a2 = MCP_TXB1CTRL;
	a3 = MCP_TXB2CTRL;
	for (i = 0; i < 14; i++) {                                          /* in-buffer loop               */
		mcp2515_setRegister(a1, 0);
		mcp2515_setRegister(a2, 0);
		mcp2515_setRegister(a3, 0);
		a1++;
		a2++;
		a3++;
	}
	mcp2515_setRegister(MCP_RXB0CTRL, 0);
	mcp2515_setRegister(MCP_RXB1CTRL, 0);
}

/*******************************************************************
*
*    FUNCTION: mcp2515_init
*
* DESCRIPTION: Initialize Controller
*
*  PARAMETERS:  canIDMode: CAN ID Mode (Extended or Standard)
*				canSpeed: CAN speed to set.
*				canClock: CAN clock to set.
*
*     RETURNS: mcpStatus: MCP2515 status after modifying register.
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t mcp2515_init(const uint8_t canIDMode, const uint8_t canSpeed, const uint8_t canClock)
{
	uint8_t response;

    mcp2515_reset();
    
    mcpMode = MCP_LOOPBACK;

    response = mcp2515_setCANCTRL_Mode(MODE_CONFIG);
    if(response > 0)
    {
		return response;
    }

    // Set Baudrate
    if(mcp2515_configRate(canSpeed, canClock))
    {
		return response;
    }

    if ( response == MCP2515_OK ) 
	{
        mcp2515_initCANBuffers();	// Init CAN Buffers
        mcp2515_setRegister(MCP_CANINTE, MCP_RX0IF | MCP_RX1IF);	// Interrupt Mode

		//Sets BF pins as GPO
		mcp2515_setRegister(MCP_BFPCTRL,MCP_BxBFS_MASK | MCP_BxBFE_MASK);
		//Sets RTS pins as GPI
		mcp2515_setRegister(MCP_TXRTSCTRL,0x00);

        switch(canIDMode)
        {
            case (MCP_ANY):
				mcp2515_modifyRegister(MCP_RXB0CTRL,
				MCP_RXB_RX_MASK | MCP_RXB_BUKT_MASK,
				MCP_RXB_RX_ANY | MCP_RXB_BUKT_MASK);
				mcp2515_modifyRegister(MCP_RXB1CTRL, MCP_RXB_RX_MASK,
				MCP_RXB_RX_ANY);
				break;
            case (MCP_STDEXT): 
				mcp2515_modifyRegister(MCP_RXB0CTRL,
				MCP_RXB_RX_MASK | MCP_RXB_BUKT_MASK,
				MCP_RXB_RX_STDEXT | MCP_RXB_BUKT_MASK );
				mcp2515_modifyRegister(MCP_RXB1CTRL, MCP_RXB_RX_MASK,
				MCP_RXB_RX_STDEXT);
				break;
            default:  
				return MCP2515_FAIL;
				break;
		}    

        response = mcp2515_setCANCTRL_Mode(mcpMode);                                                                
        if(response)
        {
			return response;
        }
    }
    return response;
}

/*******************************************************************
*
*    FUNCTION: mcp2515_write_id
*
* DESCRIPTION: Write CAN ID
*
*  PARAMETERS:  regAddress: MCP2515 register address.
*				isExt: Is Id Extended or Standard
*				id: CAN ID
*
*     RETURNS: mcpStatus: MCP2515 status after modifying register.
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
void mcp2515_write_id( const uint8_t regAddress, const uint8_t isExt, const uint32_t id )
{
	uint16_t canID;
	uint8_t tbufdata[4];

	canID = (uint16_t)(id & 0x0FFFF);

	if ( isExt == 1 )
	{
		tbufdata[MCP_EID0] = (uint8_t) (canID & 0xFF);
		tbufdata[MCP_EID8] = (uint8_t) (canID >> 8);
		canID = (uint16_t)(id >> 16);
		tbufdata[MCP_SIDL] = (uint8_t) (canID & 0x03);
		tbufdata[MCP_SIDL] += (uint8_t) ((canID & 0x1C) << 3);
		tbufdata[MCP_SIDL] |= MCP_TXB_EXIDE_M;
		tbufdata[MCP_SIDH] = (uint8_t) (canID >> 5 );
	}
	else
	{
		tbufdata[MCP_SIDH] = (uint8_t) (canID >> 3 );
		tbufdata[MCP_SIDL] = (uint8_t) ((canID & 0x07 ) << 5);
		tbufdata[MCP_EID0] = 0;
		tbufdata[MCP_EID8] = 0;
	}
	
	mcp2515_setRegisterSuccessive( regAddress, tbufdata, 4 );
}

/*******************************************************************
*
*    FUNCTION: mcp2515_write_mf
*
* DESCRIPTION: Write Masks and Filters
*
*  PARAMETERS:  regAddress: MCP2515 register address.
*				isExt: Is Id Extended or Standard
*				id: CAN ID
*
*     RETURNS: mcpStatus: MCP2515 status after modifying register.
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
void mcp2515_write_mf ( const uint8_t regAddress, const uint8_t isExt, const uint32_t id )
{
	uint16_t canid;
	uint8_t tbufdata[4];

	canid = (uint16_t)(id & 0x0FFFF);

	if ( isExt == 1)
	{
		tbufdata[MCP_EID0] = (uint8_t) (canid & 0xFF);
		tbufdata[MCP_EID8] = (uint8_t) (canid >> 8);
		canid = (uint16_t)(id >> 16);
		tbufdata[MCP_SIDL] = (uint8_t) (canid & 0x03);
		tbufdata[MCP_SIDL] += (uint8_t) ((canid & 0x1C) << 3);
		tbufdata[MCP_SIDL] |= MCP_TXB_EXIDE_M;
		tbufdata[MCP_SIDH] = (uint8_t) (canid >> 5 );
	}
	else
	{
		tbufdata[MCP_EID0] = (uint8_t) (canid & 0xFF);
		tbufdata[MCP_EID8] = (uint8_t) (canid >> 8);
		canid = (uint16_t)(id >> 16);
		tbufdata[MCP_SIDL] = (uint8_t) ((canid & 0x07) << 5);
		tbufdata[MCP_SIDH] = (uint8_t) (canid >> 3 );
	}
	
	mcp2515_setRegisterSuccessive( regAddress, tbufdata, 4 );
}

/*******************************************************************
*
*    FUNCTION: mcp2515_read_id
*
* DESCRIPTION: Read CAN ID
*
*  PARAMETERS:  regAddress: MCP2515 register address.
*				isExt: pointer to Is Id Extended or Standard
*				id: CAN ID
*
*     RETURNS: mcpStatus: MCP2515 status after modifying register.
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
void mcp2515_read_id( const uint8_t regAddress, uint8_t *isExt, uint32_t *id )
{
	uint8_t tbufdata[4];

	*isExt = 0;
	*id = 0;

	mcp2515_readRegisterSuccessive( regAddress, tbufdata, 4 );

	*id = (tbufdata[MCP_SIDH]<<3) + (tbufdata[MCP_SIDL]>>5);

	if ( (tbufdata[MCP_SIDL] & MCP_TXB_EXIDE_M) ==  MCP_TXB_EXIDE_M )
	{
		/* extended id                  */
		*id = (*id<<2) + (tbufdata[MCP_SIDL] & 0x03);
		*id = (*id<<8) + tbufdata[MCP_EID8];
		*id = (*id<<8) + tbufdata[MCP_EID0];
		*isExt = 1;
	}
}

/*******************************************************************
*
*    FUNCTION: mcp2515_write_canMsg
*
* DESCRIPTION: Write CAN message
*
*  PARAMETERS:  buffer_sidh_addr: MC2515 ID register address
*
*     RETURNS: N/A
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
void mcp2515_write_canMsg( const uint8_t buffer_sidh_addr )
{
	uint8_t regAddress;
	regAddress = buffer_sidh_addr;
	mcp2515_setRegisterSuccessive(regAddress + 5, mcpData, mcpDataLen );                  /* write data bytes             */
	
	if ( mcpRemoteFlg == 1)                                                   /* if RTR set bit in byte       */
	mcpDataLen |= MCP_RTR_MASK;

	mcp2515_setRegister((regAddress+4), mcpDataLen );                         /* write the RTR and DLC        */
	mcp2515_write_id(regAddress, mcpIDExtFlg, mcpID );                      /* write CAN id                 */
}

/*******************************************************************
*
*    FUNCTION: mcp2515_read_canMsg
*
* DESCRIPTION: Read CAN message
*
*  PARAMETERS:  buffer_sidh_addr: MC2515 ID register address
*
*     RETURNS: N/A
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
void mcp2515_read_canMsg( const uint8_t buffer_sidh_addr)
{
	uint8_t regAddress, ctrl;

	regAddress = buffer_sidh_addr;

	mcp2515_read_id( regAddress, &mcpIDExtFlg,&mcpID );

	ctrl = mcp2515_readRegister( regAddress - 1 );
	mcpDataLen = mcp2515_readRegister( regAddress + 4 );

	if (ctrl & 0x08)
	{
		mcpRemoteFlg = 1;
	}
	else
	{
		mcpRemoteFlg = 0;
	}

	mcpDataLen &= MCP_DLC_MASK;
	mcp2515_readRegisterSuccessive( regAddress + 5, &(mcpData[0]), mcpDataLen );
}

/*******************************************************************
*
*    FUNCTION: mcp2515_getNextFreeTXBuf
*
* DESCRIPTION: Find empty transmit buffer
*
*  PARAMETERS:  txbuf_n: Pointer to out buffer
*
*     RETURNS: response: MCP2515 status
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t mcp2515_getNextFreeTXBuf(uint8_t *txbuf_n)
{
	uint8_t response, i, ctrlval;
	uint8_t ctrlregs[MCP_N_TXBUFFERS] = { MCP_TXB0CTRL, MCP_TXB1CTRL, MCP_TXB2CTRL };

	response = MCP_ALLTXBUSY;
	*txbuf_n = 0x00;

	/* check all 3 TX-Buffers       */
	for (i=0; i<MCP_N_TXBUFFERS; i++) {
		ctrlval = mcp2515_readRegister( ctrlregs[i] );
		if ( (ctrlval & MCP_TXB_TXREQ_M) == 0 ) {
			*txbuf_n = ctrlregs[i]+1;                                   /* return SIDH-address of Buffer*/
			
			response = MCP2515_OK;
			return response;                                                 /* ! function exit              */
		}
	}
	return response;
}

/*****************************************************************************************************
* CAN operator function
*****************************************************************************************************/

/*******************************************************************
*
*    FUNCTION: CAN_Init
*
* DESCRIPTION: Initialize instance of MCP2515 with chipSelect pin
*
*  PARAMETERS:  chipSelect: MCP2515 chip select pin number
*
*     RETURNS: response: MCP2515 status
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
void CAN_Init(uint8_t chipSelect)
{
	mcpChipSelect = chipSelect;
}

/*******************************************************************
*
*    FUNCTION: CAN_Set_Msg
*
* DESCRIPTION: set CAN Message
*
*  PARAMETERS:  id: Pointer to out buffer
*				rtr: Remote flag
*				ext: Is the message extended or standard
*				len: Data length
*				pData: pointer to data
*
*     RETURNS: response: MCP2515 status
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Set_Msg(uint32_t id, uint8_t rtr, uint8_t ext, uint8_t len, uint8_t *pData)
{
	uint8_t iterator = 0;
	
	mcpID = id;
	mcpRemoteFlg = rtr;
	mcpIDExtFlg = ext;
	mcpDataLen = len;
	for(iterator = 0; iterator < MAX_CHAR_IN_MESSAGE; iterator++)
	{
		mcpData[iterator] = *(pData + iterator);
	}
	
	return MCP2515_OK;
}

/*******************************************************************
*
*    FUNCTION: CAN_Clear_Msg
*
* DESCRIPTION: Clear all messages to zero
*
*  PARAMETERS: N/A
*
*     RETURNS: response: MCP2515 status
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Clear_Msg(void)
{
	uint8_t data = 0;
	
	mcpID			= 0;
	mcpDataLen      = 0;
	mcpIDExtFlg		= 0;
	mcpRemoteFlg    = 0;
	mcpFilterHit	= 0;
	for( data = 0; data < mcpDataLen; data++ )
	{
		mcpData[data] = 0x00;
	}
	
	return MCP2515_OK;
}

/*******************************************************************
*
*    FUNCTION: CAN_Read_Msg
*
* DESCRIPTION: Read CAN message
*
*  PARAMETERS: N/A
*
*     RETURNS: response: MCP2515 status
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Read_Msg(void)
{
	uint8_t status, response;

	status = mcp2515_readStatus();

	if ( status & MCP_STAT_RX0IF )                                        /* Msg in Buffer 0              */
	{
		mcp2515_read_canMsg( MCP_RXBUF_0);
		mcp2515_modifyRegister(MCP_CANINTF, MCP_RX0IF, 0);
		response = CAN_OK;
	}
	else if ( status & MCP_STAT_RX1IF )                                   /* Msg in Buffer 1              */
	{
		mcp2515_read_canMsg( MCP_RXBUF_1);
		mcp2515_modifyRegister(MCP_CANINTF, MCP_RX1IF, 0);
		response = CAN_OK;
	}
	else
	response = CAN_NOMSG;
	
	return response;
}

/*******************************************************************
*
*    FUNCTION: CAN_Send_Msg
*
* DESCRIPTION: Send CAN message
*
*  PARAMETERS: N/A
*
*     RETURNS: response: CAN Status
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Send_Msg(void)
{
	uint8_t response, res1, txbuf_n;
	uint16_t uiTimeOut = 0;

	do {
		response = mcp2515_getNextFreeTXBuf(&txbuf_n);                       /* info = addr.                 */
		uiTimeOut++;
	} while (response == MCP_ALLTXBUSY && (uiTimeOut < TIMEOUTVALUE));

	if(uiTimeOut == TIMEOUTVALUE)
	{
		return CAN_GETTXBFTIMEOUT;                                      /* get tx buff time out         */
	}
	uiTimeOut = 0;
	mcp2515_write_canMsg( txbuf_n);
	mcp2515_modifyRegister( txbuf_n-1 , MCP_TXB_TXREQ_M, MCP_TXB_TXREQ_M );
	
	do
	{
		uiTimeOut++;
		res1 = mcp2515_readRegister(txbuf_n-1);                         /* read send buff ctrl reg 	*/
		res1 = res1 & 0x08;
	} while (res1 && (uiTimeOut < TIMEOUTVALUE));
	
	if(uiTimeOut == TIMEOUTVALUE)                                       /* send msg timeout             */
	{
		return CAN_SENDMSGTIMEOUT;
	}
	
	return CAN_OK;
}

/*******************************************************************
*
*    FUNCTION: CAN_Begin
*
* DESCRIPTION: Initialize controller parameters
*
*  PARAMETERS: idModeSet: Id mode (ext or std)
*				speedSet: CAN speed
*				clockSet: CAN clock
*
*     RETURNS: CAN Status
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Begin(uint8_t idModeSet, uint8_t speedSet, uint8_t clockSet)
{
	uint8_t response;

	response = mcp2515_init(idModeSet, speedSet, clockSet);
	if (response == MCP2515_OK)
	{
		return CAN_OK;
	}
	
	return CAN_FAILINIT;
}

/*******************************************************************
*
*    FUNCTION: CAN_Init_Mask
*
* DESCRIPTION: Initialize Mask(s)
*
*  PARAMETERS: numMask: number of mask
*				isExt: is ID ext or std
*				ulData: mask data
*
*     RETURNS: CAN Status
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Init_Mask(uint8_t numMask, uint8_t isExt, uint32_t ulData)
{
	uint8_t res = MCP2515_OK;
	res = mcp2515_setCANCTRL_Mode(MODE_CONFIG);
	if(res > 0){
		return res;
	}
	
	if (numMask == 0){
		mcp2515_write_mf(MCP_RXM0SIDH, isExt, ulData);

	}
	else if(numMask == 1){
		mcp2515_write_mf(MCP_RXM1SIDH, isExt, ulData);
	}
	else res =  MCP2515_FAIL;
	
	res = mcp2515_setCANCTRL_Mode(mcpMode);
	if(res > 0)
	{
		return res;
	}
	
	return res;
}

/*******************************************************************
*
*    FUNCTION: CAN_Init_Filters
*
* DESCRIPTION: Initialize Filter(s)
*
*  PARAMETERS: numMask: Mask number
*				isExt: Is Id ext or std
*				ulData: mask data
*
*     RETURNS: CAN Status
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Init_Filters(uint8_t numMask, uint8_t isExt, uint32_t ulData)
{
	uint8_t res = MCP2515_OK;
	res = mcp2515_setCANCTRL_Mode(MODE_CONFIG);
	if(res > 0)
	{
		return res;
	}
	
	switch( numMask )
	{
		case 0:
		mcp2515_write_mf(MCP_RXF0SIDH, isExt, ulData);
		break;

		case 1:
		mcp2515_write_mf(MCP_RXF1SIDH, isExt, ulData);
		break;

		case 2:
		mcp2515_write_mf(MCP_RXF2SIDH, isExt, ulData);
		break;

		case 3:
		mcp2515_write_mf(MCP_RXF3SIDH, isExt, ulData);
		break;

		case 4:
		mcp2515_write_mf(MCP_RXF4SIDH, isExt, ulData);
		break;

		case 5:
		mcp2515_write_mf(MCP_RXF5SIDH, isExt, ulData);
		break;

		default:
		res = MCP2515_FAIL;
	}
	
	res = mcp2515_setCANCTRL_Mode(mcpMode);
	if(res > 0)
	{
		return res;
	}
	
	return res;
}

/*******************************************************************
*
*    FUNCTION: CAN_Set_Mode
*
* DESCRIPTION: Set operational mode
*
*  PARAMETERS: opMode: MCP2515 operation mode
*
*     RETURNS: CAN Status
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Set_Mode(uint8_t opMode)
{
	mcpMode = opMode;
	return mcp2515_setCANCTRL_Mode(mcpMode);
}

/*******************************************************************
*
*    FUNCTION: CAN_Send_Msg_Buf
*
* DESCRIPTION: Send message to transmit buffer
*
*  PARAMETERS: id: Message id
*				isExt: Is msg ext or std
*				dataLen: Data length of msg to send
*				dataBuff: pointer to data buffer
*
*     RETURNS: CAN Status
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Send_Msg_Buf(uint32_t id, uint8_t isExt, uint8_t dataLen, uint8_t *dataBuff) 
{
	uint8_t res;
	
	CAN_Set_Msg(id, 0, isExt, dataLen, dataBuff);
	res = CAN_Send_Msg();
	
	return res;
}

/*******************************************************************
*
*    FUNCTION: CAN_Read_Msg_Buf
*
* DESCRIPTION: Read message from receive buffer
*
*  PARAMETERS: id: pointer to msg id
*				dataLen: pointer to Data length of msg
*				dataBuff: pointer to data buffer
*
*     RETURNS: CAN Status
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Read_Msg_Buf(uint32_t *id, uint8_t *dataLen, uint8_t dataBuff[])
{
	if( CAN_Read_Msg() == CAN_NOMSG )
	{
		return CAN_NOMSG;
	}
	
	if ( mcpIDExtFlg)
	{
		mcpID |= 0x80000000;
	}
	if ( mcpRemoteFlg )
	{
		mcpID |= 0x40000000;
	}
	
	*id = mcpID;
	*dataLen = mcpDataLen;
	for( uint8_t data = 0; data < mcpDataLen; data++)
	{
		dataBuff[data] = mcpData[data];
	}

	return CAN_OK;
}

/*******************************************************************
*
*    FUNCTION: CAN_Check_Receive
*
* DESCRIPTION: Check for received data
*
*  PARAMETERS: N/A
*
*     RETURNS: CAN Status
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Check_Receive(void)
{
	uint8_t response = CAN_NOMSG;
	response = mcp2515_readStatus();                                         /* RXnIF in Bit 1 and 0         */
	if ( response & MCP_STAT_RXIF_MASK )
	{
		return CAN_MSGAVAIL;
	}
	
	return response;
}

/*******************************************************************
*
*    FUNCTION: CAN_Check_Error
*
* DESCRIPTION: Check for errors
*
*  PARAMETERS: N/A
*
*     RETURNS: CAN Status
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Check_Error(void)
{
	uint8_t response = CAN_OK;
	uint8_t eflg = mcp2515_readRegister(MCP_EFLG);

	if ( eflg & MCP_EFLG_ERRORMASK )
	{
		response = CAN_CTRLERROR;
	}
	
	return response;
}

/*******************************************************************
*
*    FUNCTION: CAN_Get_Error
*
* DESCRIPTION: Check for errors
*
*  PARAMETERS: N/A
*
*     RETURNS: MCP2515 Error
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Get_Error(void)
{
	return mcp2515_readRegister(MCP_EFLG);
}

/*******************************************************************
*
*    FUNCTION: CAN_Error_Count_RX
*
* DESCRIPTION: Get error count
*
*  PARAMETERS: N/A
*
*     RETURNS: MCP2515 count RX Error
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Error_Count_RX(void)
{
	return mcp2515_readRegister(MCP_REC);
}

/*******************************************************************
*
*    FUNCTION: CAN_Error_Count_TX
*
* DESCRIPTION: Get error count
*
*  PARAMETERS: N/A
*
*     RETURNS: MCP2515 count TX Error
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Error_Count_TX(void)
{
	return mcp2515_readRegister(MCP_TEC);
} 

/*******************************************************************
*
*    FUNCTION: CAN_Enable_One_Shot_TX
*
* DESCRIPTION: Enable one-shot transmission mode
*
*  PARAMETERS: N/A
*
*     RETURNS: CAN status
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Enable_One_Shot_TX(void)
{
	uint8_t response = CAN_OK;
	
	mcp2515_modifyRegister(MCP_CANCTRL, MODE_ONESHOT, MODE_ONESHOT);
	
	if((mcp2515_readRegister(MCP_CANCTRL) & MODE_ONESHOT) != MODE_ONESHOT)
	{
		response = CAN_FAIL;
	}
	
	return response;
}

/*******************************************************************
*
*    FUNCTION: CAN_Disable_One_Shot_TX
*
* DESCRIPTION: Disable one-shot transmission
*
*  PARAMETERS: N/A
*
*     RETURNS: CAN Status
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Disable_One_Shot_TX(void)
{
	uint8_t response = CAN_OK;
	
	mcp2515_modifyRegister(MCP_CANCTRL, MODE_ONESHOT, 0);
	if((mcp2515_readRegister(MCP_CANCTRL) & MODE_ONESHOT) != 0)
	{
		response = CAN_FAIL;
	}
	
	return response;
}

/*******************************************************************
*
*    FUNCTION: CAN_Abort_TX
*
* DESCRIPTION: Abort queued transmission(s)
*
*  PARAMETERS: N/A
*
*     RETURNS: CAN Status
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Abort_TX(void)
{
	uint8_t response = CAN_OK;
	mcp2515_modifyRegister(MCP_CANCTRL, ABORT_TX, ABORT_TX);
	
	// Maybe check to see if the TX buffer transmission request bits are cleared instead?
	if((mcp2515_readRegister(MCP_CANCTRL) & ABORT_TX) != ABORT_TX)
	{
		response = CAN_FAIL;
	}
	
	return response;
}

/*******************************************************************
*
*    FUNCTION: CAN_Set_GPO
*
* DESCRIPTION: Sets GPO
*
*  PARAMETERS: N/A
*
*     RETURNS: Return 0
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Set_GPO(uint8_t data)
{
	mcp2515_modifyRegister(MCP_BFPCTRL, MCP_BxBFS_MASK, (data<<4));
	
	return 0;
}

/*******************************************************************
*
*    FUNCTION: CAN_Get_GPI
*
* DESCRIPTION: Reads GPI
*
*  PARAMETERS: N/A
*
*     RETURNS: Return 0
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
uint8_t CAN_Get_GPI(void)
{
	uint8_t response;
	
	response = mcp2515_readRegister(MCP_TXRTSCTRL) & MCP_BxRTS_MASK;
	
	return (response >> 3);
}