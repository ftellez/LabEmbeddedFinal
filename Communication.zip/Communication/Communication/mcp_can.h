/*
 * mcp_can.h
 *
 * Created: 6/20/2018 10:26:03 AM
 *  Author: rg93876
 */ 


#ifndef MCP_CAN_H_
#define MCP_CAN_H_

/** Includes *******************************/
#include "sam.h"
#include "mcp_can_dfs.h"
#include "spi.h"

#define MAX_CHAR_IN_MESSAGE 8
#define DUMMY 0x00

/*****************************************************************************************************
* mcp2515 driver function
*****************************************************************************************************/
void mcp2515_reset(void);										// Soft Reset MCP2515
uint8_t mcp2515_readRegister(const uint8_t address);			// Read MCP2515 register           
void mcp2515_readRegisterSuccessive(const uint8_t address,		// Read MCP2515 successive registers
							uint8_t values[], 
							const uint8_t numRegToRead);
void mcp2515_setRegister(const uint8_t address,                 // Set MCP2515 register
							const uint8_t value);
void mcp2515_setRegisterSuccessive(const uint8_t address,                // Set MCP2515 successive registers
							const uint8_t values[],
							const uint8_t numRegToWrite);
void mcp2515_modifyRegister(const uint8_t address,              // Set specific bit(s) of a register
							const uint8_t mask,
							const uint8_t data);

uint8_t mcp2515_readStatus(void);								// Read MCP2515 Status
uint8_t mcp2515_setCANCTRL_Mode(const uint8_t operationMode);	// Set mode
uint8_t mcp2515_configRate( const uint8_t canSpeed,             // Set baud rate
							const uint8_t canClock);

void mcp2515_initCANBuffers(void);								// Initialize buffers, Masks and filters
uint8_t mcp2515_init(const uint8_t canIDMode,                   // Initialize Controller
						const uint8_t canSpeed,
						const uint8_t canClock);

void mcp2515_write_id( const uint8_t mcp_addr,                  // Write CAN ID
						const uint8_t isExt,
						const uint32_t id );
						
void mcp2515_write_mf ( const uint8_t regAddress,				// Write Masks and Filters
						const uint8_t isExt, 
						const uint32_t id );

void mcp2515_read_id( const uint8_t mcp_addr,                   // Read CAN ID
						uint8_t* ext,
						uint32_t* id );

void mcp2515_write_canMsg( const uint8_t buffer_sidh_addr );	// Write CAN message
void mcp2515_read_canMsg( const uint8_t buffer_sidh_addr);      // Read CAN message
uint8_t mcp2515_getNextFreeTXBuf(uint8_t *txbuf_n);             // Find empty transmit buffer

/*****************************************************************************************************
* CAN operator function
*****************************************************************************************************/
void CAN_Init(uint8_t chipSelect);														// Initialize instance of MCP2515 with chipSelect pin
uint8_t CAN_Begin(uint8_t idmodeset, uint8_t speedset, uint8_t clockset);				// Initialize controller parameters
uint8_t CAN_Init_Mask(uint8_t num, uint8_t isExt, uint32_t ulData);						// Initialize Mask(s)
uint8_t CAN_Init_Filters(uint8_t num, uint8_t isExt, uint32_t ulData);					// Initialize Filter(s)
uint8_t CAN_Set_Mode(uint8_t opMode);													// Set operational mode
uint8_t CAN_Set_Msg(uint32_t id, uint8_t rtr, uint8_t ext, uint8_t len, uint8_t *pData);// Set message
uint8_t CAN_Clear_Msg(void);															// Clear all message to zero
uint8_t CAN_Read_Msg(void);																// Read message
uint8_t CAN_Send_Msg(void);																// Send message
uint8_t CAN_Send_Msg_Buf(uint32_t id, uint8_t ext, uint8_t len, uint8_t *buf);			// Send message to transmit buffer
uint8_t CAN_Read_Msg_Buf(uint32_t *id, uint8_t *dataLen, uint8_t dataBuff[]);			// Read message from receive buffer
uint8_t CAN_Check_Receive(void);														// Check for received data
uint8_t CAN_Check_Error(void);															// Check for errors
uint8_t CAN_Get_Error(void);															// Check for errors
uint8_t CAN_Error_Count_RX(void);														// Get error count
uint8_t CAN_Error_Count_TX(void);														// Get error count
uint8_t CAN_Enable_One_Shot_TX(void);													// Enable one-shot transmission
uint8_t CAN_Disable_One_Shot_TX(void);													// Disable one-shot transmission
uint8_t CAN_Abort_TX(void);																// Abort queued transmission(s)
uint8_t CAN_Set_GPO(uint8_t data);														// Sets GPO
uint8_t CAN_Get_GPI(void);																// Reads GPI

#endif /* MCP_CAN_H_ */