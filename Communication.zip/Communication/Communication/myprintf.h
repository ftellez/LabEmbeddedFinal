/*
 * myprintf.h
 *
 * Created: 6/21/2018 1:38:53 PM
 *  Author: rg93876
 */ 


#ifndef MYPRINTF_H_
#define MYPRINTF_H_

/** Includes **********************************/
#include <stdarg.h>
#include <stddef.h>
#include "uart.h"

/*******************************************************************
*
*    FUNCTION: _putchar
*
* DESCRIPTION: Send char via the USART interface.
*
*  PARAMETERS: charToSend: 8 bit data to send.
*
*     RETURNS: N/A
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
void _putchar(char charToSend);

/*******************************************************************
*
*    FUNCTION: my_printf
*
* DESCRIPTION: Tiny printf implementation to format and output strings via USART interface
*
*  PARAMETERS: format: string that specifies the format of the output
*
*     RETURNS: number of characters that are written into the array
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
int my_printf(const char *format, ...);

/*******************************************************************
*
*    FUNCTION: my_sprintf
*
* DESCRIPTION: Tiny sprintf implementation to format strings. Recommend to use (v)snprintf instead due to buffer overflow!
*  PARAMETERS:	buffer: A pointer to the buffer where to store the formatted string. MUST be big enough to store the output!
*				format: A string that specifies the format of the output
*
*     RETURNS: The number of characters that are WRITTEN into the buffer, not counting the terminating null character
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
int my_sprintf(char* buffer, const char* format, ...);

/*******************************************************************
*
*    FUNCTION: my_snprintf
*
* DESCRIPTION:	Tiny snprintf implementation
*  PARAMETERS:	buffer: A pointer to the buffer where to store the formatted string.
*				count: The maximum number of characters to store in the buffer, including a terminating null character
*				format: A string that specifies the format of the output
*
*     RETURNS:	The number of characters that are WRITTEN into the buffer, not counting the terminating null character
*				If the formatted string is truncated the buffer size (count) is returned
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
int  my_snprintf(char* buffer, size_t count, const char* format, ...);

/*******************************************************************
*
*    FUNCTION: my_vsnprintf
*
* DESCRIPTION:	Tiny vsnprintf implementation
*  PARAMETERS:	buffer: A pointer to the buffer where to store the formatted string.
*				count: The maximum number of characters to store in the buffer, including a terminating null character
*				format: A string that specifies the format of the output
*
*     RETURNS:	The number of characters that are WRITTEN into the buffer, not counting the terminating null character
*				If the formatted string is truncated the buffer size (count) is returned
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
int my_vsnprintf(char* buffer, size_t count, const char* format, va_list va);

/*******************************************************************
*
*    FUNCTION: my_fctprintf
*
* DESCRIPTION:	printf with output function. You may use this as dynamic alternative to printf() with its fixed _putchar() output
*  PARAMETERS:	out: An output function which takes one character and an argument pointer
*				arg: An argument pointer for user data passed to output function
*				format: A string that specifies the format of the output
*
*     RETURNS: The number of characters that are sent to the output function, not counting the terminating null character
*
*  REENTRANCY: N/A
*
*     HISTORY:
*
*******************************************************************/
int my_fctprintf(void (*out)(char character, void* arg), void* arg, const char* format, ...);

#endif /* MYPRINTF_H_ */