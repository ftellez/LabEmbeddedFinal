#include "samd21.h"
#include "myprintf.h"
#include "spi.h"

#define RXBUFSIZE 0x400
#define LENGTH_R1 0x03
#define LENGTH_R7 0x07

void initUART2(void);
void initCycles(void);
uint32_t xchg_spi(const uint8_t * send_buff, uint32_t bc, uint8_t * receive_buff);
void rcvr_datablock(const uint8_t * send_buff, uint32_t lba, uint8_t * receive_buff, uint32_t bs);

#define SIZE_SD_CMD 0x06
#define kCMD00 0x40
#define kCMD08 0x48
#define kCMD55 0x77
#define kCMD41 0x69

const uint8_t CMD00[SIZE_SD_CMD]  ={0x40, 0x00, 0x00, 0x00, 0x00, 0x95};
const uint8_t CMD08[SIZE_SD_CMD]  ={0x48, 0x00, 0x00, 0x01, 0xAA, 0x87};
uint8_t CMD17[SIZE_SD_CMD]  ={0x51, 0x00, 0x00, 0x00, 0x00, 0x01};
uint8_t CMD172[SIZE_SD_CMD]  ={0x51, 0x00, 0x00, 0x08, 0x00, 0x01};
const uint8_t CMD18[SIZE_SD_CMD]  ={0x52, 0x00, 0x00, 0x00, 0x00, 0x01};
const uint8_t CMD55[SIZE_SD_CMD]  ={0x77, 0x00, 0x00, 0x00, 0x00, 0x65};
const uint8_t CMD41[SIZE_SD_CMD] = {0x69, 0x40, 0x00, 0x00, 0x00, 0x77};

uint8_t RxBuffer[RXBUFSIZE];

int main2(void)
{
  uint32_t temp = 0xFF;
  /* Initialize the SAM system */
  SystemInit();
  /* Switch to 8MHz clock (disable prescaler) */
  SYSCTRL->OSC8M.bit.PRESC = 0;
  initUART2();
  initSPIsd();

  initCycles();
  //myprintf("\n");
  
  while (RxBuffer[0] != 0x01) {xchg_spi(CMD00, SIZE_SD_CMD, RxBuffer);}
  xchg_spi(CMD08, SIZE_SD_CMD, RxBuffer);	
  if(RxBuffer[0] & (1 << 2)){
       //Is illegal so its older version of SD
  }else{
	if(RxBuffer[0] & (1 << 3)){
		while(1){
			xchg_spi(CMD55, SIZE_SD_CMD, RxBuffer);
			xchg_spi(CMD41, SIZE_SD_CMD, RxBuffer);
			// Evaluate IDLE STATE, if 0, SD is ready
			if(RxBuffer[0] == 0x0)
				break;
		}
		myprintf("\nReady");
		rcvr_datablock(CMD17, 0x00, RxBuffer, 512);
	}
  }
  myprintf("\nDone");
}

uint32_t xchg_spi(const uint8_t * send_buff, uint32_t bc, uint8_t * receive_buff) {
  uint8_t temp = 0x00;
  uint32_t i;
  uint8_t temp_cmd = send_buff[0];
  
  REG_PORT_OUTCLR0 = PORT_PA18;
  for(i=0; i< bc; i++) {
    temp = spiSend(*(send_buff++));
    myprintf(" %x", temp);
  }
  
  while(1){
     temp = spiSend(0xFF);
     if( !(temp & 0x08) ){
	break;
     }
  }

  receive_buff[0] = temp;

  switch(temp_cmd) {
    case kCMD00 :
      myprintf("\n");
      break;
    case kCMD08 :
      for(i=1; i<LENGTH_R7; i++) {
        temp = spiSend(0xFF);
	receive_buff[i] = temp;
      }
      myprintf("\n");
      break;
    case kCMD41 :
      for(i=1; i<LENGTH_R1; i++) {
        temp = spiSend(0xFF);
	receive_buff[i] = temp;
      }
      myprintf("\n");
      break;
    case kCMD55 :
      for(i=1; i<LENGTH_R1; i++) {	
        temp = spiSend(0xFF);
	receive_buff[i] = temp;
      }
      myprintf("\n");
      break;
    default :
      myprintf("\n Error in CMD");
  }
  REG_PORT_OUTSET0 = PORT_PA18;
  return(temp);
}

void initCycles(void){
  uint32_t i;
  REG_PORT_OUTSET0 = PORT_PA18;
  for(i=0;i<76;i++)
  spiSend(0xFF);
}


void rcvr_datablock(const uint8_t * send_buff, uint32_t lba, uint8_t * receive_buff, uint32_t bs ) {
  uint8_t temp = 0xFF;
  uint32_t i;
  
  REG_PORT_OUTCLR0 = PORT_PA18;
  myprintf("\n\n");

  temp = send_buff[0];
  temp = spiSend(temp);
  myprintf(" %x", temp);
  temp = ((uint8_t*)&lba)[3];
  temp = spiSend(temp);
  myprintf(" %x", temp);

  // Complete the code that is missing


  temp = send_buff[5];
  temp = spiSend(temp);
  myprintf(" %x", temp);

  // Reading to find the beginning of the sector

  temp = spiSend(0xFF);
  while(temp != 0xFE){
    temp = spiSend(0xFF);
    myprintf(" %x", temp);
  }
  
  // Receiving the memory sector/block
  
  myprintf("\n\n");
  for(i=0; i< bs; i++) {
    while(SERCOM1->SPI.INTFLAG.bit.DRE == 0);
    SERCOM1->SPI.DATA.reg = 0xFF;
    while(SERCOM1->SPI.INTFLAG.bit.TXC == 0);
    while(SERCOM1->SPI.INTFLAG.bit.RXC == 0);
    temp = SERCOM1->SPI.DATA.reg;
    *(receive_buff++) = temp;
    myprintf(" %x", temp);
  }
  REG_PORT_OUTSET0 = PORT_PA18;
  myprintf("\n\n");
}


uint8_t spiSend(uint8_t data) {
  uint8_t temp;
  while(SERCOM1->SPI.INTFLAG.bit.DRE == 0);
  SERCOM1->SPI.DATA.reg = data;
  while(SERCOM1->SPI.INTFLAG.bit.TXC == 0);
  while(SERCOM1->SPI.INTFLAG.bit.RXC == 0);
  temp = SERCOM1->SPI.DATA.reg;
  my_printf(" %x",temp);
  return temp;
}

void initSPIsd(void) {
           PM->APBCMASK.bit.SERCOM1_ = 1;
           GCLK->CLKCTRL.reg = GCLK_CLKCTRL_CLKEN | GCLK_CLKCTRL_ID_SERCOM1_CORE;
           while(GCLK->STATUS.bit.SYNCBUSY);
           const SERCOM_SPI_CTRLA_Type ctrla = {
                  .bit.DORD = 0, // Set as MSB first
                  .bit.CPHA = 0, // Set as Mode 0
                  .bit.CPOL = 0,  // Keep this as 0
                  .bit.FORM = 0x0, // Set as SPI frame
                  .bit.DIPO = 0x3, // Set as MISO on PAD[3]
                  .bit.DOPO = 0x0, // Set as MOSI on PAD[0], SCK on PAD[1], SS_ on PAD[2]
                  .bit.MODE = 0x3  // Set as Master
           };
           SERCOM1->SPI.CTRLA.reg = ctrla.reg;
           const SERCOM_SPI_CTRLB_Type ctrlb = {
                  .bit.RXEN = 1,   // Set as RX enabled
                  .bit.MSSEN = 0,  // Set as HW SS
                  .bit.CHSIZE = 0x0  // Set as 8-bit
           };
           SERCOM1->SPI.CTRLB.reg = ctrlb.reg;
 
           SERCOM1->SPI.BAUD.reg = 0; // Rate is clock / 2
           // Mux for SERCOM1 PA16,PA17,PA18,PA19
           const PORT_WRCONFIG_Type wrconfig = {
           .bit.WRPINCFG = 1,
           .bit.WRPMUX = 1,
           .bit.PMUX = MUX_PA16C_SERCOM1_PAD0,
           .bit.PMUXEN = 1,
           .bit.HWSEL = 1,
           .bit.PINMASK =(uint16_t)((PORT_PA16|PORT_PA17|PORT_PA18|PORT_PA19) >> 16)
           };
           PORT->Group[0].WRCONFIG.reg = wrconfig.reg;
 
           SERCOM1->SPI.CTRLA.bit.ENABLE = 1;
           while(SERCOM1->SPI.SYNCBUSY.bit.ENABLE);
		   
		  
}

void SPI_Slave_Select(uint8_t device)
{
	switch(device)
	{
		case 0:
		PORT->Group[0].PINCFG[PIN_PA10].bit.PMUXEN = 0;
		break;
		case 1:
		PORT->Group[0].PINCFG[PIN_PA11].bit.PMUXEN = 0;
		break;
	}
}

void initUART2(void) {
	/* port mux configuration*/
	PORT->Group[0].DIR.reg |= (1 << 10);                  /* Pin 10 configured as output */
	PORT->Group[0].PINCFG[PIN_PA11].bit.PMUXEN = 1;       /* Enabling peripheral functions */
	PORT->Group[0].PINCFG[PIN_PA10].bit.PMUXEN = 1;       /* Enabling peripheral functions */
	
	/*PMUX: even = n/2, odd: (n-1)/2 */
	PORT->Group[0].PMUX[5].reg |= 0x02;                   /* Selecting peripheral function C */
	PORT->Group[0].PMUX[5].reg |= 0x20;                   /* Selecting peripheral function C */
	
	/* APBCMASK */
	//PM->APBCMASK.reg |= PM_APBCMASK_SERCOM0;			  /* SERCOM 0 enable*/
	PM->APBCMASK.reg |= PM_APBCMASK_SERCOM0;

	/*GCLK configuration for sercom0 module: using generic clock generator 0, ID for sercom0, enable GCLK*/

	GCLK->CLKCTRL.reg = GCLK_CLKCTRL_ID(SERCOM0_GCLK_ID_CORE) |
	GCLK_CLKCTRL_CLKEN | GCLK_CLKCTRL_GEN(0);

	
	/* configure SERCOM0 module for UART as Standard Frame, 8 Bit size, No parity, BAUDRATE:9600*/

	SERCOM0->USART.CTRLA.reg =
	SERCOM_USART_CTRLA_DORD | SERCOM_USART_CTRLA_MODE_USART_INT_CLK |
	SERCOM_USART_CTRLA_RXPO(3/*PAD3*/) | SERCOM_USART_CTRLA_TXPO(1/*PAD2*/);
	
	uint64_t br = (uint64_t)65536 * (8000000 - 16 * 9600) / 8000000;
	
	SERCOM0->USART.CTRLB.reg = SERCOM_USART_CTRLB_RXEN | SERCOM_USART_CTRLB_TXEN | SERCOM_USART_CTRLB_CHSIZE(0/*8 bits*/);

	SERCOM0->USART.BAUD.reg = (uint16_t)br;

	SERCOM0->USART.CTRLA.reg |= SERCOM_USART_CTRLA_ENABLE;
}

void SPI_Slave_Unselect(uint8_t device)
{

	switch(device)
	{
	case 0:
	PORT->Group[0].PINCFG[PIN_PA10].bit.PMUXEN = 0;
	break;
	case 1:
	PORT->Group[0].PINCFG[PIN_PA11].bit.PMUXEN = 0;
	break;
	
	}

}