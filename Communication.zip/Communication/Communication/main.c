/*
 * Communication.c
 *
 * Created: 11/16/2018 2:04:16 PM
 * Author : Embebidos
 */ 


#include "sam.h"
#include "myprintf.h"
#include "mcp_can_dfs.h"
#include "mcp_can.h"
#include "uart.h"
#include "spi.h"
#define CAN0_SPEED CAN_500KBPS

	uint16_t canID = 0;
	uint8_t dataLength = 0;
	uint8_t arr[8] = {0,0,0,0,0,0,0,0};
	uint8_t message;
	
	
int main(void)
{
	uint8_t device = 0;
	uint32_t mask = 0xFFFF;
	uint32_t filter = 0xF004;
    /* Initialize the SAM system */
	initUART();
	initSPIsd();
	CAN_Init(device);
	CAN_Begin(canID, CAN0_SPEED, MCP_16MHZ);
	CAN_Set_Mode(device);

	
    /* Replace with your application code */
    while (1) 
    {
	message = CAN_Read_Msg_Buf(&canID, &dataLength,arr);
	my_printf("ID: %\n", canID);
	my_printf("Data Length: %x\n",dataLength);
	my_printf("%x %x %x %x %x %x %x %x\n",arr[0],arr[1],arr[2],arr[3],
	arr[4],arr[5],arr[6],arr[7]);
    }
	mcp2515_modifyRegister(&canID,mask,filter);
	
}
