/*
* spi.h
*/ 
#ifndef SPI_H_
#define SPI_H_
#include "sam.h"
void	initSPIsd(void);
uint8_t  spiSend (uint8_t data);
void  SPI_Slave_Select(uint8_t device);
void  SPI_Slave_Unselect(uint8_t device);
#endif /* SPI_H_ */